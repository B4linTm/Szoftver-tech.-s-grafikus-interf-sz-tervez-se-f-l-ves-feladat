﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Repository
{
    public class FormaDbContext : DbContext
    {
        public DbSet<Championship> Championships { get; set;}
        public DbSet<Team> Teams { get; set;}
        public DbSet<Driver> Drivers { get; set;}

        public FormaDbContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase("formuladb").UseLazyLoadingProxies();
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region foreignkeys
            modelBuilder.Entity<Team>()
                .HasOne(t => t.Championship)
                .WithMany(t => t.Teams)
                .HasForeignKey(t => t.ChampionshipId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Driver>()
                .HasOne(t => t.Team)
                .WithMany(t => t.Drivers)
                .HasForeignKey(t => t.TeamId)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
            #endregion


            #region championshipslist
            var champsionships = new List<Championship>()
            {
                new Championship(){Id = 1, ChampionshipName = "F1", HasFineAfterRuleBreak = true},
                new Championship(){Id = 2, ChampionshipName = "F2", HasFineAfterRuleBreak = true},
                new Championship(){Id = 3, ChampionshipName = "F3", HasFineAfterRuleBreak = true},
            };
            

            modelBuilder.Entity<Championship>().HasData(champsionships);
            #endregion


            #region teams

            var teams = new List<Team>()
            {
                new Team(){Id = 1, ChampionshipId = 1, Name = "Red Bull Racing", HasOwnMotor = true},
                new Team(){Id = 2, ChampionshipId = 1, Name = "Mercedes", HasOwnMotor = true},
                new Team(){Id = 3, ChampionshipId = 1, Name = "Ferrari", HasOwnMotor = true},
                new Team(){Id = 4, ChampionshipId = 1, Name = "McLaren", HasOwnMotor = false},
                new Team(){Id = 5, ChampionshipId = 2, Name = "Prema Racing", HasOwnMotor = false},
                new Team(){Id = 6, ChampionshipId = 2, Name = "Rodin Carlin", HasOwnMotor = false},
                new Team(){Id = 7, ChampionshipId = 3, Name = "Mp Motorsport", HasOwnMotor = false},
                new Team(){Id = 8, ChampionshipId = 3, Name = "Art Grand Prix", HasOwnMotor = false},
            };

            modelBuilder.Entity<Team>().HasData(teams);
            #endregion

            #region drivers

            var drivers = new List<Driver>()
            {
                new Driver(){Id = 1, Name = "Max Verstappen", Age = 26, Salary = 55000000, ShiftWithRighthand = true, TeamId = 1 },
                new Driver(){Id = 2, Name = "Sergio Pérez", Age = 33, Salary = 10000000, ShiftWithRighthand = true, TeamId = 1 },
                new Driver(){Id = 3, Name = "Lewis Hamilton", Age = 38, Salary = 35000000, ShiftWithRighthand = true, TeamId = 2 },
                new Driver(){Id = 4, Name = "George Russel", Age = 25, Salary = 10000000, ShiftWithRighthand = true, TeamId = 2 },
                
            };

            modelBuilder.Entity<Driver>().HasData(drivers);
            #endregion




            
        }
    }
}

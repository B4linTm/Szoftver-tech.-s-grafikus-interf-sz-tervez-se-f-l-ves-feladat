﻿using ConsoleTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.Threading;
using System.Security.Cryptography;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Client
{
    public class Program
    {
        static Service service;

        static void Main(string[] args)
        {
            service = new Service("http://localhost:6102/", "championship");

            var championshipmenu = new ConsoleMenu(args, level: 1)
                .Add("List", () => List("Championship"))
                .Add("Create", () => Create("Championship"))
                .Add("Delete", () => Delete("Championship"))
                .Add("Has own motor", () => HasOwnMotor("Championship"))
                .Add("Update", () => Update("Championship"))
                .Add("Exit", ConsoleMenu.Close);

            var teammenu = new ConsoleMenu(args, level: 1)
                .Add("List", () => List("Team"))
                .Add("Create", () => Create("Team"))
                .Add("Delete", () => Delete("Team"))
                .Add("Average salary", () => AvGSalary("Team"))
                .Add("Update", () => Update("Team"))
                .Add("Exit", ConsoleMenu.Close);


            var drivermenu = new ConsoleMenu(args, level: 1)
                .Add("List", () => List("Driver"))
                .Add("Create", () => Create("Driver"))
                .Add("Delete", () => Delete("Driver"))
                .Add("Update", () => Update("Driver"))
                .Add("Older than parameter", () => OlderThanParameter("Driver"))
                .Add("Oldest driver", () => OldestDriver("Driver"))
                .Add("Youngest driver", () => YoungestDriver("Driver"))
                
                .Add("Exit", ConsoleMenu.Close);

            var mainmenu = new ConsoleMenu(args, level: 0)
                .Add("Championships", () => championshipmenu.Show())
                .Add("Teams", () => teammenu.Show())
                .Add("Drivers", () => drivermenu.Show())
                .Add("Exit", ConsoleMenu.Close);

            mainmenu.Show();



        }




        static void Create(string parameter)
        {
            if (parameter == "Championship")
            {
                Console.Write("Champsionship name: ");
                string name = Console.ReadLine();
                Console.Write("Has a fine after rulebreak?");
                bool hasfine = bool.Parse(Console.ReadLine());
                service.Post(new Championship()
                {
                    ChampionshipName = name,
                    HasFineAfterRuleBreak = hasfine
                }, "championship");
            }
            else if (parameter == "Driver")
            {
                Console.Write("Driver name: ");
                string name = Console.ReadLine();
                Console.Write("Driver salary: ");
                int salary = int.Parse(Console.ReadLine());
                Console.Write("Driver age: ");
                int age = int.Parse(Console.ReadLine());
                Console.Write("Driver team id: ");
                int tid = int.Parse(Console.ReadLine());
                Console.Write("Shift with right hand?");
                bool rhand = bool.Parse(Console.ReadLine());
                service.Post(new Driver
                {
                    Name = name,
                    Salary = salary,
                    Age = age,
                    Id = tid,
                    ShiftWithRighthand = rhand
                }, "driver");
            }

            else if (parameter == "Team")
            {
                Console.Write("Team name: ");
                string name = Console.ReadLine();
                Console.Write("Championship id: ");
                int cid = int.Parse(Console.ReadLine());
                Console.Write("Has own motor?");
                bool hasownmotor = bool.Parse(Console.ReadLine());
                service.Post(new Team()
                {
                    Name = name,
                    ChampionshipId = cid,
                    HasOwnMotor = hasownmotor
                }, "team");
            }
            Console.ReadLine();
        }

        static void List(string parameter)
        {
            if (parameter == "Championship")
            {
                List<Championship> champsionships = service.Get<Championship>("champsionship");
                foreach (var ch in champsionships)
                {
                    Console.WriteLine("[" + ch.Id + "]" + ch.ChampionshipName);
                }
            }
            else if (parameter == "Driver")
            {
                List<Driver> drivers = service.Get<Driver>("driver");
                foreach (var dr in drivers)
                {
                    Console.WriteLine("[" + dr.Id + "]" + dr.Name);
                }
            }
            else if (parameter == "Team")
            {
                List<Team> teams = service.Get<Team>("team");
                foreach (var team in teams)
                {
                    Console.WriteLine("[" + team.Id + "]" + team.Name);
                }
            }
            Console.ReadLine();
        }

        static void Update(string parameter)
        {
            if (parameter == "Championship")
            {
                Console.WriteLine("Champsionship id to change: ");
                int id = int.Parse(Console.ReadLine());
                Championship champships = service.Get<Championship>(id, "championship");
                Console.WriteLine("Old champsionhip name: " + champships.ChampionshipName + " , new name: ");
                string newname = Console.ReadLine();
                champships.ChampionshipName = newname;
                service.Put(champships, "championships");
            }
            else if (parameter == "Driver")
            {
                Console.WriteLine("Driver id to change: ");
                int id = int.Parse(Console.ReadLine());
                Driver driver = service.Get<Driver>(id, "driver");
                Console.WriteLine("Old name: " + driver.Name + " , newm name: ");
                string newname = Console.ReadLine();
                driver.Name = newname;
                service.Put(driver, "driver");
            }
            else if (parameter == "Team")
            {
                Console.WriteLine("Team id to change: ");
                int id = int.Parse(Console.ReadLine());
                Team team = service.Get<Team>(id, "team");
                Console.WriteLine("Old name: " + team.Name + " , nem name: ");
                string newname = Console.ReadLine();
                team.Name = newname;
                service.Put(team, "team");
            }
        }

        static void Delete(string parameter)
        {
            if (parameter == "Championship")
            {
                Console.WriteLine("Championship id to delete: ");
                int id = int.Parse(Console.ReadLine());
                service.Delete(id, "championship");
            }
            else if (parameter == "Driver")
            {
                Console.WriteLine("Driver id to delete: ");
                int id = int.Parse(Console.ReadLine());
                service.Delete(id, "driver");
            }
            else if (parameter == "Team")
            {
                Console.WriteLine("Team id to delete: ");
                int id = int.Parse(Console.ReadLine());
                service.Delete(id, "team");
            }
        }


        static void OlderThanParameter(string parameter)
        {
            Console.WriteLine("Drivers older than: ");
            int olderthan = int.Parse(Console.ReadLine());
            
                IEnumerable<Driver> olddrivers = service.Get<Driver>("Info/GetDriversOlderthanparameter/" + olderthan);

            

            foreach (var item in olddrivers)
            {
                Console.WriteLine(item.Name);
            }





            Console.ReadLine();
        }
        
        static void OldestDriver(string parameter)
        {
            int oldest = service.GetSingle<int>("Info/GetOldestDriver");
            Console.WriteLine("The oldest driver's age: " + oldest);
            Console.ReadLine();
        }

        static void YoungestDriver(string parameter)
        {
            int youngest = service.GetSingle<int>("Info/GetYoungestDriver");
            Console.WriteLine("The youngest driver's age: " + youngest);
            Console.ReadLine();
        }


        static void AvGSalary(string parameter) 
        {
            Console.WriteLine("Team Id: ");
            int id = int.Parse(Console.ReadLine());
            double avg = service.GetSingle<double>("Info/AvarageSalaryInTeam/"+ id);
            Console.WriteLine(avg);
            Console.ReadLine();
        }

        static void HasOwnMotor(string parameter)
        {
            var hasown = service.Get<HasOwnMotorInfo>("HasOwnMotorInfo/GetOwn");
            foreach (var item in hasown)
            {
                Console.WriteLine("Championship Id: " + item.ChampionshipId);
                Console.WriteLine("Has own motor : " + item.HasOwnMotorTeamS);

            }
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Repository
{
    public class ChampionshipRepository : Repository<Championship>, IRepository<Championship>
    {
        public ChampionshipRepository(FormaDbContext context) : base(context)
        {
            
        }
        public override Championship Read(int id)
        {
            return this.Context.Championships.First(x => x.Id == id);
        }

        public override void Update(Championship item)
        {
            var Older = Read(item.Id);
            foreach (var prop in Older.GetType().GetProperties())
            {
                if (prop.GetAccessors().FirstOrDefault(t => t.IsVirtual) == null)
                {
                    prop.SetValue(Older, prop.GetValue(item));
                }

            }
            Context.SaveChanges();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Models;
using VPJS7P_HFT_2023241.Repository;

namespace VPJS7P_HFT_2023241.Logic
{
    public class ChampionshipLogic : IChampionshipLogic
    {
        IRepository<Championship> repo;

        public ChampionshipLogic(IRepository<Championship> repo)
        {
            this.repo = repo;
        }

        public void Create(Championship item)
        {
            if (item.Id < 0)
            {
                throw new ArgumentException("The Id must be higher than 0");
            }
            else
            {
                this.repo.Create(item);
            }
        }

        public void Delete(int id)
        {
            this.repo.Delete(id);
        }

        public IEnumerable<HasOwnMotorInfo> GetHasOwnMotorInfo()
        {
            var info = from x in this.repo.ReadAll()
                       from z in x.Teams
                       group z by z.ChampionshipId into g
                       select new HasOwnMotorInfo
                       {
                           ChampionshipId = g.Key,
                           HasOwnMotorTeamS = g.Count(t => t.HasOwnMotor)
                       };

            return info;
        }

        public Championship Read(int id)
        {
            if (this.repo.Read(id) == null)
            {
                throw new ArgumentException("The championship does not exists");
            }
            return this.repo.Read(id);
        }

        public IEnumerable<Championship> ReadAll()
        {
            return this.repo.ReadAll();
        }

        public void Update(Championship item)
        {
            this.repo.Update(item);
        }
    }
}

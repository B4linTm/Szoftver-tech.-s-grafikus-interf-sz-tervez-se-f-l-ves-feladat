﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Logic;
using VPJS7P_HFT_2023241.Models;
using VPJS7P_HFT_2023241.Repository;

namespace VPJS7P_HFT_2023241.Test
{
    [TestFixture]
    public class DriverTest
    {
        DriverLogic driver;
        Mock<IRepository<Driver>> mockDriverRepo;

        [SetUp]
        public void Init()
        {
            mockDriverRepo = new Mock<IRepository<Driver>>();
            driver = new DriverLogic(mockDriverRepo.Object);
        }

        [Test]
        public void Test()
        {
            var dr = new Driver(2, "Jakab Béla", 3000, 27, 1, false);
            driver.Create(dr);
            mockDriverRepo.Verify(x => x.Create(dr), Times.Once);
        }

        [Test]
        public void Youngest()
        {
            mockDriverRepo.Setup(x => x.ReadAll()).Returns(new List<Driver>()
            {
                new Driver(1, "Lakatos Márk", 50000, 34, 2, true),
                new Driver(2, "Kiss Géza", 40000, 44, 2, false),
                new Driver(3, "Balogh András", 10000, 23, 3, true),
            }.AsQueryable());

            driver = new DriverLogic(mockDriverRepo.Object);

            Assert.That(driver.GetYoungestDriver() == 23);
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System.Collections.Generic;
using VPJS7P_HFT_2023241.Endpoint.Services;
using VPJS7P_HFT_2023241.Logic;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Endpoint.Controller
{
    [Route("[controller]")]
    [ApiController]
    public class DriverController : ControllerBase
    {
        IDriverLogic driverlogic;
        IHubContext<SignalRHub> hub;

        public DriverController(IDriverLogic driverlogic, IHubContext<SignalRHub> hub)
        {
            this.driverlogic = driverlogic;
            this.hub = hub;
        }

        

        [HttpGet]
        public IEnumerable<Driver> ReadAll()
        {
            return this.driverlogic.ReadAll();
        }

        [HttpGet("{id}")]
        public Driver Read(int id)
        {
            return this.driverlogic.Read(id);
            
        }

        [HttpPost]
        public void Create([FromBody] Driver value)
        {
            this.driverlogic.Create(value);
            this.hub.Clients.All.SendAsync("DriverCreated", value);
        }

        [HttpPut]
        public void Update([FromBody] Driver value)
        {
            this.driverlogic.Update(value);
            this.hub.Clients.All.SendAsync("DriverUpdated", value);
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var drivertodelete = this.driverlogic.Read(id);
            this.driverlogic.Delete(id);
            this.hub.Clients.All.SendAsync("DriverDeleted", drivertodelete);
        }
    }
}

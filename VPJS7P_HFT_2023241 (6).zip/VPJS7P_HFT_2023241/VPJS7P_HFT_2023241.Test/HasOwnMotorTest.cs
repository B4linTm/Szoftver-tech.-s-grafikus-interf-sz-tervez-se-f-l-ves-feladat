﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Logic;
using VPJS7P_HFT_2023241.Models;
using VPJS7P_HFT_2023241.Repository;

namespace VPJS7P_HFT_2023241.Test
{
    [TestFixture]
    public class HasOwnMotorTest
    {
        DriverLogic dl;
        TeamLogic tl;
        ChampionshipLogic cl;

        Mock<IRepository<Driver>> mockDriverRepo;
        Mock<IRepository<Team>> mockTeamRepo;
        Mock<IRepository<Championship>> mockChampionshipRepo;

        HasOwnMotorInfo hasownmotor;

        [SetUp]

        public void Init()
        {
            mockDriverRepo = new Mock<IRepository<Driver>>();
            mockTeamRepo = new Mock<IRepository<Team>>();
            mockChampionshipRepo = new Mock<IRepository<Championship>>();

            mockDriverRepo.Setup(x => x.ReadAll()).Returns(new List<Driver>()
            {
                new Driver(1, "Verstappen", 1000, 24, 1, true),
                new Driver(2, "Alonso", 5000, 30, 2, true),
                new Driver(3, "Russel", 10000, 27, 1, true),
            }.AsQueryable());

            mockTeamRepo.Setup(x => x.ReadAll()).Returns(new List<Team>()
            {
                new Team(1, "Red Bull", 1, true),
                new Team(2, "Mercedes", 1, true),
                new Team(3, "Alfa Romeo", 1, false),
            }.AsQueryable());

            mockChampionshipRepo.Setup(x => x.ReadAll()).Returns(new List<Championship>()
            {
                new Championship(1, "F1", true),
                new Championship(2, "F2", true),
                new Championship(3, "F3", true),

            }.AsQueryable());

            dl = new DriverLogic(mockDriverRepo.Object);
            tl = new TeamLogic(mockTeamRepo.Object);
            cl = new ChampionshipLogic(mockChampionshipRepo.Object);

            hasownmotor = new HasOwnMotorInfo(1, 2);

            


        }

        [Test]
        public void HasOwnMotorCorrect()
        {
            Assert.That(hasownmotor.HasOwnMotorTeamS == 2);
        }

        [Test]
        public void HasOwnMotorNotCorrect()
        {
            Assert.That(hasownmotor.HasOwnMotorTeamS != 5);
        }

        [Test]
        public void HasOwnMotortest()
        {
            Assert.That(hasownmotor.ChampionshipId == 1);
        }

        [Test]
        public void HasNotOwnMotortest()
        {
            Assert.AreNotEqual(hasownmotor.ChampionshipId, 2);
        }
    }
}

﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Logic;
using VPJS7P_HFT_2023241.Models;
using VPJS7P_HFT_2023241.Repository;

namespace VPJS7P_HFT_2023241.Test
{
    [TestFixture]
    public class ChampionshipTest
    {

        ChampionshipLogic championship;
        Mock<IRepository<Championship>> mockChampionshipRepo;

        [SetUp]

        public void Init()
        {
            mockChampionshipRepo = new Mock<IRepository<Championship>>();
            mockChampionshipRepo.Setup(x => x.ReadAll()).Returns(new List<Championship>()
            {
                new Championship(1, "F1", true),
                new Championship(2, "F2", true),
                new Championship(3, "F3", true),
            }.AsQueryable());
            championship = new ChampionshipLogic(mockChampionshipRepo.Object);
        }

        [Test]
        public void ChampionshipGood()
        {
            var ch = new Championship(4, "F4", false);
            championship.Create(ch);
            mockChampionshipRepo.Verify(x => x.Create(ch), Times.Once());
        }

        [Test]
        public void ChampionshisnotGood()
        {
            var ch = new Championship(-2, "F20", false);
            try
            {
                championship.Create(ch);
            }
            catch (ArgumentException)
            {

                
            }
            mockChampionshipRepo.Verify(x => x.Create(ch), Times.Never());
        }

        [Test]
        public void ChampionshipReadTest()
        {
            try
            {
                championship.Read(1);
            }
            catch
            {

                
            }
            mockChampionshipRepo.Verify(x => x.Read(1), Times.Once());

        }
    }
}

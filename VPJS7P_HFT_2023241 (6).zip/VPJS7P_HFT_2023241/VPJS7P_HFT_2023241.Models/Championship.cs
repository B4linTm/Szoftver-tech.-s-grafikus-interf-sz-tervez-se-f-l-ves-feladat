﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace VPJS7P_HFT_2023241.Models
{
    public class Championship
    {
        

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string ChampionshipName { get; set; }
        public bool HasFineAfterRuleBreak { get; set; }
        [NotMapped]
        [JsonIgnore]
        public virtual ICollection<Team> Teams { get; set; }

        

        public Championship()
        {

        }

        public Championship(int id, string championshipName, bool hasFineAfterRuleBreak)
        {
            Id = id;
            ChampionshipName = championshipName;
            HasFineAfterRuleBreak = hasFineAfterRuleBreak;
        }
    }
}

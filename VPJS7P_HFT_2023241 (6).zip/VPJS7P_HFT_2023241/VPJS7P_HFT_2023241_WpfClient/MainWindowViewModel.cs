﻿using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Xml.Linq;
using VPJS7P_HFT_2023241.Models;
using VPJS7P_HFT_2023241.WpfClient;

namespace VPJS7P_HFT_2023241_WpfClient
{
    public class MainWindowViewModel : ObservableRecipient
    {
        public RestCollection<Driver> Drivers { get; set; }

        private Driver selectedDriver;

        public Driver SelectedDriver
        {
            get { return selectedDriver; }
            set
            {
                if (value != null)
                {
                    selectedDriver = new Driver()
                    {
                        Name = value.Name,
                        Age = value.Age,
                        Id = value.Id

                    };
                    OnPropertyChanged();

                    (DeleteDriverCommand as RelayCommand).NotifyCanExecuteChanged();
                }

            }
        }

        public RestCollection<Team> Teams { get; set; }
        private Team selectedTeam;
        public Team SelectedTeam
        {
            get { return selectedTeam; }
            set
            {
                if (value != null)
                {
                    selectedTeam = new Team()
                    {

                        Name = value.Name,
                        Id = value.Id

                    };
                    OnPropertyChanged();
                    (DeleteTeamCommand as RelayCommand).NotifyCanExecuteChanged();
                }
            }
        }

        public RestCollection<Championship> Championships { get; set; }
        private Championship selectedChampionship;
        public Championship SelectedChampionship
        {
            get { return selectedChampionship; }
            set
            {
                if (value != null)
                {
                    selectedChampionship = new Championship()
                    {
                        Id = value.Id,
                        ChampionshipName = value.ChampionshipName


                    };
                    OnPropertyChanged();
                    (DeleteChampionshipCommand as RelayCommand).NotifyCanExecuteChanged();
                }
            }
        }
        public string AgeAvarage { get; set; }
        public string Youngest { get; set; }
        public string Oldest { get; set; }

        public ICommand CreateDriverCommand { get; set; }
        public ICommand DeleteDriverCommand { get; set; }
        public ICommand UpdateDriverCommand { get; set; }

        public ICommand CreateTeamCommand { get; set; }
        public ICommand DeleteTeamCommand { get; set; }
        public ICommand UpdateTeamCommand { get; set; }

        public ICommand CreateChampionshipCommand { get; set; }
        public ICommand DeleteChampionshipCommand { get; set; }
        public ICommand UpdateChampionshipCommand { get; set; }
        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }

        public MainWindowViewModel()
        {

            if (!IsInDesignMode)
            {
                #region Drivers
                Drivers = new RestCollection<Driver>("http://localhost:6102/", "driver");
                CreateDriverCommand = new RelayCommand(() =>
                {
                    Drivers.Add(new Driver()
                    {

                        Name = SelectedDriver.Name,
                        Age = SelectedDriver.Age,
                        Id = SelectedDriver.Id



                    });
                });
                UpdateDriverCommand = new RelayCommand(() =>
                {
                    Drivers.Update(SelectedDriver);
                });

                DeleteDriverCommand = new RelayCommand(() =>
                {
                    Drivers.Delete(SelectedDriver.Id);
                },
                () =>
                {
                    return SelectedDriver != null;
                });
                SelectedDriver = new Driver();
                #endregion

                #region Teams
                Teams = new RestCollection<Team>("http://localhost:6102/", "team");
                CreateTeamCommand = new RelayCommand(() =>
                {
                    Teams.Add(new Team()
                    {

                        Name = SelectedTeam.Name,

                        Id = SelectedTeam.Id
                    });

                });
                UpdateTeamCommand = new RelayCommand(() =>
                {
                    Teams.Update(SelectedTeam);
                });

                DeleteTeamCommand = new RelayCommand(() =>
                {
                    Teams.Delete(SelectedTeam.Id);
                },
                () =>
                {
                    return SelectedTeam != null;
                });
                SelectedTeam = new Team();
                #endregion

                #region Championships
                Championships = new RestCollection<Championship>("http://localhost:6102/", "championship");
                CreateChampionshipCommand = new RelayCommand(() =>
                {
                    Championships.Add(new Championship()
                    {
                        Id = SelectedChampionship.Id,
                        ChampionshipName = SelectedChampionship.ChampionshipName


                    });

                });
                UpdateChampionshipCommand = new RelayCommand(() =>
                {
                    Championships.Update(SelectedChampionship);
                });

                DeleteChampionshipCommand = new RelayCommand(() =>
                {
                    Championships.Delete(SelectedChampionship.Id);
                },
                () =>
                {
                    return SelectedChampionship != null;
                });
                SelectedChampionship = new Championship();
                #endregion

                


            }



        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VPJS7P_HFT_2023241.Models
{
    public class HasOwnMotorInfo
    {
        public int ChampionshipId { get; set; }
        public int  HasOwnMotorTeamS {  get; set; }

        public HasOwnMotorInfo()
        {
            
        }
        public HasOwnMotorInfo(int championshipId, int hasOwnMotorTeamS)
        {
            ChampionshipId = championshipId;
            HasOwnMotorTeamS = hasOwnMotorTeamS;
        }



    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using VPJS7P_HFT_2023241.Endpoint.Services;
using VPJS7P_HFT_2023241.Logic;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Endpoint.Controller
{
    [Route("[controller]")]
    [ApiController]
    public class ChampionshipController : ControllerBase
    {
        IChampionshipLogic chlogic;
        IHubContext<SignalRHub> hub;

        public ChampionshipController(IChampionshipLogic chlogic, IHubContext<SignalRHub> hub)
        {
            this.chlogic = chlogic;
            this.hub = hub;
        }

        

        [HttpGet]
        public IEnumerable<Championship> ReadAll()
        {
            return this.chlogic.ReadAll();
        }

        [HttpGet("{id}")]
        public Championship Read(int id)
        {
            return this.chlogic.Read(id);
        }

        [HttpPost]
        public void Create([FromBody] Championship value)
        {
            this.chlogic.Create(value);
            this.hub.Clients.All.SendAsync("ChampionshipCreated", value);
        }

        [HttpPut]
        public void Update([FromBody] Championship value)
        {
            this.chlogic.Update(value);
            this.hub.Clients.All.SendAsync("ChampionshipUpdated", value);
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var chtodelete = this.chlogic.Read(id);
            this.chlogic.Delete(id);
            this.hub.Clients.All.SendAsync("ChampionshipDeleted", chtodelete);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VPJS7P_HFT_2023241.Models
{
    public class Driver
    {
        

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }
        public int Age { get; set; }
        [ForeignKey(nameof(Team))]
        public int TeamId { get; set; }
        public bool ShiftWithRighthand { get; set; }
        [NotMapped]
        public virtual Team Team { get; set; }

        public Driver()
        {

        }

        public Driver(int id, string name, int salary, int age, int teamId, bool shiftWithRighthand)
        {
            Id = id;
            Name = name;
            Salary = salary;
            Age = age;
            TeamId = teamId;
            ShiftWithRighthand = shiftWithRighthand;
        }
    }
}

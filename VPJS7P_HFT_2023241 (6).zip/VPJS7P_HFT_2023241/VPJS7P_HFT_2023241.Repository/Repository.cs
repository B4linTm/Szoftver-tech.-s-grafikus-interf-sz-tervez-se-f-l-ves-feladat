﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VPJS7P_HFT_2023241.Repository
{
    public abstract class Repository<T> : IRepository<T> where T : class
    {
        public FormaDbContext Context;

        protected Repository(FormaDbContext context)
        {
            this.Context = context;
        }

        public IQueryable<T> ReadAll()
        {
            return Context.Set<T>();
        }

        public abstract T Read(int id);
        
            
        

        public void Create(T item)
        {
            Context.Set<T>().Add(item);
            Context.SaveChanges();
        }

        public abstract void Update(T item);
        
            
        

        public void Delete(int id)
        {
            Context.Set<T>().Remove(Read(id));
            Context.SaveChanges();
        }
    }
}

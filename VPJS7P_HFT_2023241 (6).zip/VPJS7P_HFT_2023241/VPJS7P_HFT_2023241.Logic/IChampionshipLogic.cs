﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Logic
{
    public interface IChampionshipLogic
    {
        void Create(Championship item);
        void Delete(int id);
        IEnumerable<HasOwnMotorInfo> GetHasOwnMotorInfo();

        Championship Read(int id);
        IEnumerable<Championship> ReadAll();
        void Update(Championship item);
    }
}

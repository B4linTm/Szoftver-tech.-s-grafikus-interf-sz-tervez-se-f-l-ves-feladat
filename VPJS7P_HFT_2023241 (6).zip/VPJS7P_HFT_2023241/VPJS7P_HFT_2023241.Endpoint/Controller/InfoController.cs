﻿using Microsoft.AspNetCore.Mvc;
using System.Collections;
using System.Collections.Generic;
using VPJS7P_HFT_2023241.Logic;
using VPJS7P_HFT_2023241.Models;

namespace VPJS7P_HFT_2023241.Endpoint.Controller
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class InfoController : ControllerBase
    {
        ITeamLogic teamlogic;
        IDriverLogic driverlogic;

        public InfoController(ITeamLogic teamlogic, IDriverLogic driverlogic)
        {
            this.teamlogic = teamlogic;
            this.driverlogic = driverlogic;
        }

        [HttpGet("{age}")]
        public IEnumerable<Driver> OlderthanX(int x)
        {
            return this.driverlogic.GetDriversOlderthanparameter(x);
        }

        [HttpGet]
        public int OldestDriver()
        {
            return this.driverlogic.GetOldestDriver();
        }

        [HttpGet]
        public int YoungestDriver()
        {
            return this.driverlogic.GetYoungestDriver();
        }

        [HttpGet("{avginteamiD}")]
        public double AvgSalary(int avgsalary)
        {
            return this.teamlogic.AvarageSalaryInTeam(avgsalary);
        }
    }
}

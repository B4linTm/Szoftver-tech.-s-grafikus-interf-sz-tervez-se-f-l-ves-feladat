﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using VPJS7P_HFT_2023241.Logic;
using VPJS7P_HFT_2023241.Models;
using VPJS7P_HFT_2023241.Repository;

namespace VPJS7P_HFT_2023241.Test
{
    [TestFixture]
    public class TeamTest
    {
        TeamLogic team;
        Mock<IRepository<Team>> mockTeamRepo;

        [SetUp]
        public void Init()
        {
            mockTeamRepo = new Mock<IRepository<Team>>();
            mockTeamRepo.Setup(x => x.ReadAll()).Returns(new List<Team>()
            {
                new Team(3, "Red Bull", 1, true),
                new Team(4, "Mercedes", 1, true),
                new Team(5, "Mp MotorSport", 2, false),
            }.AsQueryable());
            team = new TeamLogic(mockTeamRepo.Object);


            
        }

        [Test]
        public void Test()
        {
            var Team = new Team(10, "Ferrari", 1, true);
            team.Create(Team);

            mockTeamRepo.Verify(x => x.Create(Team), Times.Once());
        }
    }
}
